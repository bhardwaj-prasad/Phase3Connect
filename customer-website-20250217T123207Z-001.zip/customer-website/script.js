document.querySelectorAll('.order-btn').forEach(button => {
    button.addEventListener('click', () => {
        alert('Your order has been placed!');
    });
});
